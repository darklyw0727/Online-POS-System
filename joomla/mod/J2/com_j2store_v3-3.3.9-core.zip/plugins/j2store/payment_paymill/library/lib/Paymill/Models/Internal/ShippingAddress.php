<?php

namespace Paymill\Models\Internal;

/**
 * Model ShippingAddress
 */
class ShippingAddress extends AbstractAddress
{

}
