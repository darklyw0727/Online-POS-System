<?php
/**
 * @package J2Store
 * @copyright Copyright (c)2014-17 Ramesh Elamathi / J2Store.org
 * @license GNU GPL v3 or later
 */
defined('_JEXEC') or die;

/**
 * Frontpage View class
 *
 * @since  1.5
 */
class J2StoreViewProducts extends F0FViewJson
{

	public function display($tpl = null)
	{
		return false;
	}
	protected function onDisplay($tpl = null) {

        return false;
    }

 	protected function onRead($tpl = null)
	{
		return false;
	}

}
