<?php
/**
 * @package J2Store
 * @copyright Copyright (c)2014-17 Ramesh Elamathi / J2Store.org
 * @license GNU GPL v3 or later
 */
// No direct access to this file
defined('_JEXEC') or die;

require_once(JPATH_ADMINISTRATOR.'/components/com_j2store/views/view.php');

/*this file isn't used anymore and is set to be removed'*/

class J2StoreViewShipping_Standard extends J2StoreView
{

}
